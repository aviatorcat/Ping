﻿using System;
using Wpf = System.Windows;
using WinForms = System.Windows.Forms;
using System.Windows;
using System.Windows.Threading; // For DispatcherTimer
using System.Windows.Controls; // This is where ComboBoxItem is defined

namespace NotificationApp
{
    public partial class MainWindow : Wpf.Window
    {
        private WinForms.NotifyIcon? _notifyIcon;
        private bool _allowClose = false;
        private DispatcherTimer? _pingTimer;
        private TimeSpan? _pingTime;

        public MainWindow()
        {
            InitializeComponent();
            SetupTrayIcon();
            _pingTimer = new DispatcherTimer();
            _pingTimer.Interval = TimeSpan.FromSeconds(1);
            _pingTimer.Tick += PingTimer_Tick;
        }

        private void SetupTrayIcon()
        {
            _notifyIcon = new WinForms.NotifyIcon();
            _notifyIcon.Icon = new System.Drawing.Icon("icon.ico");
            _notifyIcon.Visible = true;
            _notifyIcon.BalloonTipTitle = "Tray App";
            _notifyIcon.BalloonTipText = "Hello from your tray app!";
            _notifyIcon.BalloonTipIcon = WinForms.ToolTipIcon.Info;
            //_notifyIcon.ShowBalloonTip(5000); // Show for 5 seconds
            _notifyIcon.Text = "My Notification App";

            var contextMenu = new WinForms.ContextMenuStrip();
            var exitMenuItem = new WinForms.ToolStripMenuItem("Exit");
            exitMenuItem.Click += (s, e) =>
            {
                _allowClose = true;
                _notifyIcon.Visible = false;
                _notifyIcon.Dispose();
                Wpf.Application.Current.Shutdown();
            };
            contextMenu.Items.Add(exitMenuItem);

            _notifyIcon.ContextMenuStrip = contextMenu;

            _notifyIcon.DoubleClick += (s, e) =>
            {
                this.Show();
                this.WindowState = Wpf.WindowState.Normal;
                this.ShowInTaskbar = true; // Show in taskbar
                this.Activate();
            };
        }

        private void ShowNotification_Click(object sender, RoutedEventArgs e)
        {
            _notifyIcon?.ShowBalloonTip(3000, "Notification", "This is a custom notification!", WinForms.ToolTipIcon.Info);
        }

        private void Ping_Click(object sender, RoutedEventArgs e)
        {
            _notifyIcon?.ShowBalloonTip(3000, "Notification", "Ping!", WinForms.ToolTipIcon.Info);
        }

        private void SetPing_Click(object sender, RoutedEventArgs e)
        {
            string timeText = PingTimeBox.Text.Trim();
            string ampm = (AmPmBox.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "AM";
            if (DateTime.TryParseExact(
                    timeText + " " + ampm,
                    "h:mm tt",
                    System.Globalization.CultureInfo.InvariantCulture,
                    System.Globalization.DateTimeStyles.None,
                    out var dt))
            {
                _pingTime = dt.TimeOfDay;
                _pingTimer?.Start();
                System.Windows.MessageBox.Show($"Ping set for {dt:hh\\:mm tt}", "Ping Scheduled", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                System.Windows.MessageBox.Show("Please enter a valid time in hh:mm format and select AM or PM.", "Invalid Time", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void PingTimer_Tick(object? sender, EventArgs e)
        {
            if (_pingTime.HasValue)
            {
                var now = DateTime.Now.TimeOfDay;
                // If the current time matches the ping time (to the minute)
                if (now.Hours == _pingTime.Value.Hours && now.Minutes == _pingTime.Value.Minutes)
                {
                    _notifyIcon?.ShowBalloonTip(3000, "Notification", "Ping!", WinForms.ToolTipIcon.Info);
                    _pingTimer?.Stop(); // Only ping once
                    _pingTime = null;
                }
            }
        }

                protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
                {
                    if (!_allowClose)
                    {
                        e.Cancel = true;
                        this.Hide();
                        this.ShowInTaskbar = false;
                    }
                    else
                    {
                        base.OnClosing(e);
                    }
                }
            }
        }