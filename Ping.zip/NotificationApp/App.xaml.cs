﻿using Wpf = System.Windows;


namespace NotificationApp
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Wpf.Application
    {
    }
}

